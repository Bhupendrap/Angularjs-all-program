function myFunction() {
    alert("registered successfully");
}