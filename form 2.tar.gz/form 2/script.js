
	var app = angular.module('myApp', ['ngRoute']);


	app.config(function($routeProvider) {
		$routeProvider

			.when('/', {
				templateUrl : 'home.html',
				controller  : 'mainController'
			})

	
			.when('/about', {
				templateUrl : 'about.html',
				controller  : 'aboutController'
			})

			
			.when('/service', {
				templateUrl : 'services.html',
				controller  : 'serviceController'
			})

			.when('/help', {
				templateUrl : 'help.html',
				controller  : 'helpController'
			})


			.when('/contact', {
				templateUrl : 'contact.html',
				controller  : 'contactController'
			});
	});


	app.controller('mainController', function($scope) {
	
		$scope.message = 'Mirafra is a global product engineering services company with expertise in semiconductor design, embedded and application software.';
	});

	app.controller('aboutController', function($scope) {
		$scope.message ='Our business philosophy is to achieve excellence in providing design and software services & solutions to our clients to build next generation leadership products.';
	});
	app.controller('serviceController', function($scope) {
		$scope.message = 'Provide customized services & solutions to our clients, helping them to build next generation,cutting edge technology products.';
	});

	app.controller('contactController', function($scope) {
		$scope.message = 'Mirafra is a technology design services company with a high level of expertise in semiconductor design and embedded software development including applications with presence in main IT cities of India and across the globe.';
	});
	app.controller('helpController', function($scope) {
		$scope.message = 'Please let us know what service you are interested in by completing the form below.We will get in touch with you at the earliest.We appreciate your interest in Mirafra Technologies. Thank You.';
	});
	
app.controller('validateCtrl', function($scope) {
    $scope.user = '';
    $scope.password= '';
});

     app.controller('MyController', function ($scope) {
            $scope.IsVisible = false;
            $scope.GenerateTable = function () {
                $scope.Customers = [
                { CustomerId: 1, Name: "John Hammond", Country: "United States" },
                { CustomerId: 2, Name: "Mudassar Khan", Country: "India" },
                { CustomerId: 3, Name: "Suzanne Mathews", Country: "France" },
                { CustomerId: 4, Name: "Robert Schidner", Country: "Russia" }
               ];
                $scope.IsVisible = true;
            };
        });
    

