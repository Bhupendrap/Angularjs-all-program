
var app = angular.module("myApp", []);
app.controller("educationController", function($scope) {
	// $scope.currentDate = new Date();
  $scope.records = [
    {
      "Sn" : "001",
      "coll" : "Germany",
      "passout" : '23"05"2017',
      "mark" : "A",
    },
    {
      "Sn" : "002",
      "coll" : "Ireland",
      "passout" : '23"05"2017',
      "mark" : "A",
    },
    {
      "Sn" : "003",
      "coll" : "India",
      "passout" : '23"05"2017',
      "mark" : "B",
    },
    {
      "Sn" : "004",
      "coll" : "Africa",
      "passout" : '23"05"2017',
      "mark" : "B",
    }
    
  ]
});

