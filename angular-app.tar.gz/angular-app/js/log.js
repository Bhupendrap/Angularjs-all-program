
    var app = angular.module('myLoginApp', []);
    app.controller('validateCtrl', function($scope, $window) {
    	$scope.user='Demo';
      $scope.RedirectToURL = function() {
        var host = $window.location.host;
        var landingUrl = "../index.html";
        $window.location.href = landingUrl;
      };
    });
