
	var app = angular.module('myApp', ['ui.router']);
	app.config(function($stateProvider) {

			var home= {
        name:'home',
				url: '/home',
				templateUrl : 'pages/home.html',
				controller  : 'mainController'
			}

	
			var education= {
        name:'education',
				url: '/education',
				templateUrl : 'pages/education.html',
				controller  : 'educationController'
			}

			
			var work= {
        name:'work',
				url: '/work',
				templateUrl : 'pages/work.html',
				controller  : 'workController'
			}

			  $stateProvider.state(home);
        $stateProvider.state(education);
        $stateProvider.state(work);
	});


	app.controller('mainController', function($scope) {
	
		$scope.message = 'Everyone come and see how good I look!';

	});

	
		app.controller("educationController", function($scope) {
  		$scope.records = [
    {
      "Sn" : "001",
      "coll" : "Germany",
      "passout" : '111970',
      "mark" : "A",
    },
    {
      "Sn" : "002",
      "coll" : "Ireland",
      "passout" : '23"05"2017',
      "mark" : "A",
    },
    {
      "Sn" : "003",
      "coll" : "India",
      "passout" : '23"05"2017',
      "mark" : "B",
    },
    {
      "Sn" : "004",
      "coll" : "Africa",
      "passout" : '23"05"2017',
      "mark" : "B",
    }
    
  ]
});
// 	  app.controller("workController", function($scope, $http) {
//           $http.get('countries.json').then(function(response) {
//               $scope.countries = response.data;
//               console.log(response.data);
//           });
      	
 app.controller('homeCntrl',function homeCntrl($rootScope,$scope) {
  $scope.value=($rootScope.all = true);
}
      );

	
  app.controller('workController',function workController($scope,$http) {
     $scope.value;
          $http.get('pages/countries.json').then(function(response) {
            //alert("ghfgh");
              $scope.countries = response.data;
              console.log(response.data);
          });
       $scope.$watch('countries', function(data, oldVal){
        console.log('changed');
    });
      
 });
